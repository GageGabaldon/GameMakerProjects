# Project 4
## Feed The King
* Ashleea Holloway (amh999)
* Stefan Mihailovic (sm3377)
* Gage Gabaldon (gag252)

## Instructions

Feed the frog the bodies of the enemies to satiate the frog king. Place towers emerse yourself in the world
and keep feeding the frog to victory. Using the varied attacks of the elemental frog wizards.

Click the towers then click a valid space to place.
Click the towers again to sell or upgrade.

## Credits
* Ashleea Holloway: Created the music and sound and a few rooms along with instruction code.
* Stefan Mihailovic: Created the code and templates for the game along with some of the frog sprites. Along with
tower code and game state code.
* Gage Gabaldon: Created the state machine and the tileset for the game.
