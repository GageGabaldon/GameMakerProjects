# Project 1
## Moving Out
* Ashleea Holloway (amh999)
* Stefan Mihailovic (sm3377) 
* Gage Gabaldon (gag252)
## Instructions
MOVEMENT: "A" to move left, "D" to move right
PICK UP BOX: "F" or RMB
PUT DOWN BOX: "X"
PLACE BOX IN TRUCK: LMB
ROTATE BOX: "Q" to rotate left, "E" to rotate right

The object of the game is to fit all 9 boxes into the moving truck without the boxes overlapping like a jigsaw puzzle. Players cannot hold multiple boxes, and must put down a box before picking up a new one. Boxes can be taken out of the truck using the RMB. The game is won when all boxes have been fit inside the truck.

## Known Bugs or Issues

## Credits
* Ashleea Holloway: Created character & truck sprites, truck sequence, character movement, character picking up/ putting down boxes logic, boxParent logic
* Stefan Mihailovic: Created box sprites, title screen including truck sequence and art sprites, instruction screen
* Gage Gabaldon: Created main screen background sprite, end game screen including its sequences and art, game won sequence, logic for placing boxes into truck