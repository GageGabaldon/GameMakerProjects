# Project 2 - Tilesets

## Alien
* Ashleea Holloway (amh999)
* Stefan Mihailovic (sm3377)
* Gage Gabaldon (gag252)

## Instructions
MOVEMENT: "A" to move left, "D" to move right,
          "S" to move down a wall, "W" to move up a wall

Jump: "Spacebar" To jump up.
Grapple: "LMB" Use LMB along with the mouse to grapple to any wall or platform.

The object of the game is to collect all the hamsters from the evil guards and
escape the facility using your grapple hook and the skills to escape. Once you
find all 5 hamsters head to the UFO to escape and win the game.

## Known Bugs or Issues
Grapple like to bug out if you mess with mouse button a lot while trying to grapple
corners of blocks a little funky.

## Credits
* Ashleea Holloway: Created character sprites and animations, Created background animations
Created Path AI For guards, Created Failed Room, Created Fonts.
* Stefan Mihailovic: Created Main Level Design, Created Start Screen and End Screen,
 Helped with grapple code.
* Gage Gabaldon: Helped Create Guards Sprites, Created Main Player code and logic,
Created Start Sequence, Created End Sequence, Created Hamster Sequence, Helped with grapple Code.
