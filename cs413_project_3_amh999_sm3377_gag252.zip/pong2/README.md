# Project 3
## PONG 2
* Ashleea Holloway (amh999)
* Stefan Mihailovic (sm3377)
* Gage Gabaldon (gag252)

## Instructions

This is pong like you have never seen it before exhilarating and extravagant
and perhaps a little sexy. Play pong progress and don't die. The longer you Play
the greater the game gets. Play until you hit ten points :)

Paddle MOVEMENT
- W to move up
- D to move down

Ship MOVEMENT
- WASD to move
- Left Click to shoot

## Known Bugs or Issues
The ball decides to shoot out randomly every now and then.

## Credits
* Ashleea Holloway: Created the boss phase and the boss music along with the sequences. Created boss sprite.
* Stefan Mihailovic: Created the phase three particle system and messed with a few graphical. Created
End and Win Screens.
and code for that part aka scoreboards and phases. Created wall sprites. Created Instruction  screen.
* Gage Gabaldon: Created the base pong game the phase system and the sprites associated with it. Created
Title screen.
